package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.Employee;
import com.demo.repositories.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository empRepository;

	public Employee save(Employee e) {

		Employee emp = (Employee) empRepository.save(e);
		return emp;
	}

	public Employee updateEmployee(Employee e) {
		e.setName(e.getName());
		e.setCity(e.getCity());
		e.setSalary(e.getSalary());

		return e;

	}

	public Employee get(Long id) {
		Optional<Employee> optMovie = empRepository.findById(id);
		Employee e = null;
		if (optMovie.isPresent())
			e = optMovie.get();

		return e;
	}

	public List<Employee> getAllEmployees() {
		return empRepository.findAll();
	}

	public Employee remove(Long id) {
		Employee e = get(id);
		if (e != null) {
			empRepository.delete(e);
		}
		return e;
	}

}
