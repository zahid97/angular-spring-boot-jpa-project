package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.demo.entity.Employee;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping(path = "/api/employees")
public class EmployeeController {
	@Autowired
	EmployeeService empService;

	@GetMapping("")
	public List<Employee> getAllEmployees() {
		return empService.getAllEmployees();
	}

	@GetMapping(path = "/{empId}")
	public Employee getEmployee(@PathVariable("empId") Long id) {
		return this.empService.get(id);
	}

	@PostMapping(path = "")
	public Employee createEmployee(@RequestBody Employee e) {
		return this.empService.save(e);
	}

	@DeleteMapping(path = "/{empId}")
	public Employee delete(@PathVariable("empId") Long id) {
		return this.empService.remove(id);
	}

	@PutMapping(path = "/{empId}")
	public Employee updateEmployee(@PathVariable("empId") Long id) {
		Employee e = empService.get(id);
		if (e.getId() != null) {
			return empService.updateEmployee(e);
		} else {
			return null;
		}
	}

}
