insert into Employee(id,name,city,salary) Values (10,'zahid','Mumbai',1200.00);
insert into Employee(id,name,city,salary) Values (20,'ABC','Pune',1900.00);
insert into Employee(id,name,city,salary) Values (30,'XYZ','Chennai',1800.00);