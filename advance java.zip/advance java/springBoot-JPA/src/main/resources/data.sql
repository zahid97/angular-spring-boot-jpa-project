insert into account(name,isactive,city,country,balance,emailaddress) values('Demo',true,'Bangalore','India',10000,'demo@gmail.com');
insert into account(name,isactive,city,country,balance,emailaddress) values('Vishal',true,'Pune','India',20000,'vishal@gmail.com');
