import { Component, OnInit } from '@angular/core';
import { Course } from './course.model'; 

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  public ourCourses: Course[];

  constructor() {

      this.ourCourses = [
          new Course(1, "Angular", "5 Days", "Vishal"),
          new Course(2, "React", "7 Days", "Vishal"),
          new Course(3, "Java", "15 Days", "Vishal"),
      ]
     
   }

  ngOnInit(): void {
  }

}
