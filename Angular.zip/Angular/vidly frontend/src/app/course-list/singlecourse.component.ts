import { Component, OnInit,Input } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-singlecourse',
  templateUrl: './singlecourse.component.html',
  styleUrls: ['./singlecourse.component.css']
})
export class SinglecourseComponent implements OnInit {

  @Input() public course: Course;

  constructor() { }

  ngOnInit(): void {
  }

}
