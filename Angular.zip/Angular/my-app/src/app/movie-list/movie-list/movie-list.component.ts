import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/movie.model';
import { MovieService } from './../../Movieservice/movie.service';
import { Genre } from './../../model/genre.model';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
  public moviesList: Movie[];
  public errMessage:string 
  public hasError:boolean = false;
  constructor(private movieService:MovieService) { }
  createMovie() {
   
   const movie = { title: "new movie",dailyRentalRate: 3, numberInStock: 2, genreId: '5fa38703eeec8c1b0cebc3db' }
    this.movieService.saveMovie(movie)
      .subscribe(
        (movie: Movie) => {
          this.moviesList.unshift(movie);
          this.hasError = false;
        },
        (error:string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )
  }
  

  ngOnInit(): void {
    this.movieService.getAllMovies()
    .subscribe(
      (moviesData:Movie[])=> {
         this.moviesList = moviesData;
         this.hasError = false;
      },
      (error:string)=> {
        this.hasError = true;
        this.errMessage = error;
      }
    )
       
  }
  
 updateMovie(movie) {

    movie.title = "updated title";

    this.movieService.saveMovie(movie)
      .subscribe(
        (updatedMovie: Movie) => {
          let index = this.moviesList.indexOf(movie);
          this.moviesList[index] = updatedMovie;
          this.hasError = false;
        },
        (error:string) => {
          this.hasError = true;
          this.errMessage = error;
        }
      )

  }

  deleteMovie(id) {

    this.movieService.deleteMovie(id)
      .subscribe(
        (movie: Movie) => {
          //console.log('movie deleted...', movie)
          let m = this.moviesList.find((item) => item._id == id)
          let index = this.moviesList.indexOf(m)
          this.moviesList.splice(index, 1);
          this.hasError= false;
        },
        (error:string) => {
          this.hasError = true;
          this.errMessage = error
        }
      )

  }

}
