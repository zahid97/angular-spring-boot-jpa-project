import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ApphighlightDirective } from './directives/AppHighlight/apphighlight.directive';
import { LoginFormComponent } from './login-form/login-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterFormComponent } from './register-form/register-form.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { MovieListComponent } from './movie-list/movie-list/movie-list.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MyInterceptor } from './Movieservice/myinterseptor';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes  = [
  {path : '', component: HomeComponent},
  {path : 'login', component: LoginFormComponent},
  {path : 'register', component: RegisterFormComponent},
  {path : 'movies', component: MovieListComponent}
]



@NgModule({
  declarations: [
    AppComponent,
    ApphighlightDirective,
    LoginFormComponent,
    RegisterFormComponent,
    MovieListComponent,
    HomeComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: MyInterceptor, multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
