import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from './../Movieservice/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  constructor(private authService:AuthService , private router:Router) { }

  ngOnInit(): void {
  }
  handleLogin(loginForm:NgForm){
    // console.log('you clicked on login button...')
     console.log(loginForm.value)
    //console.log(loginForm.value)

    this.authService.login(loginForm.value)
          .subscribe(
            (response)=>{
                //store the token into local storage of browser
                localStorage.setItem('token', response)
                //navigate to movies page
                this.router.navigate(['/movies'])
            },
            (error)=>{
                console.log(error)
            }
          )
       
    
  }


}
