import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ReturnStatement } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Movie } from '../model/movie.model';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  private apiEndPoint = 'http://localhost:3900/api'
  private url = this.apiEndPoint + '/movies';

  constructor(private httpClient: HttpClient) { }
  public getAllMovies(): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>(this.url).pipe(
      catchError(this.handleError)
       )
  }

  getMovie(id: string): Observable<Movie> {
    return this.httpClient.get<Movie>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }

  saveMovie(movie): Observable<Movie> {
    if (!movie._id) {
      return this.httpClient.post<Movie>(this.url, movie).pipe(
        catchError(this.handleError)
      )
    }
    else {
      const movieUpdate = { title: movie.title, numberInStock: movie.numberInStock, dailyRentalRate: movie.dailyRentalRate, genreId: movie.genre._id }
      return this.httpClient.put<Movie>(this.url, movieUpdate).pipe(
        catchError(this.handleError)
      )
    }
  }

  public deleteMovie(id: string): Observable<Movie> {

    return this.httpClient.delete<Movie>(this.url + '/' + id).pipe(
      catchError(this.handleError)
    )
  }










  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {

      errorMessage = 'Error ' + error.error.message;
    } else {
  
      errorMessage = `Error Code : ${error.status} \n Message :  ${error.message}`
    }
    return throwError(errorMessage)
  }
  
  }











