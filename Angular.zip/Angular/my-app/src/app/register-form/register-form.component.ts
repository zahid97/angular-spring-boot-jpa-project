import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MyValidators } from './../customvalidators/customvalidators';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {
public userForm:FormGroup;

public get email(){
  return this.userForm.get('email')
}

public get password(){
  return this.userForm.get('password')
}

public get name(){
  return this.userForm.get('name')
}

  constructor() { 
    this.userForm= new FormGroup({
      email : new FormControl('',[Validators.required,Validators.minLength(6)]),
      password : new FormControl('',[Validators.required,Validators.minLength(6),,MyValidators.shouldNotContainSpaces]),
      name : new FormControl('',Validators.required)
    })
  }
handleSubmit(){
    console.log(this.userForm.value)
    console.log("submitted");
  }

  ngOnInit(): void {
  }

}
