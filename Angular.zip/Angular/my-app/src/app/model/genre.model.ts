export class Genre{

    constructor(public _id: string, private name: string){}
}