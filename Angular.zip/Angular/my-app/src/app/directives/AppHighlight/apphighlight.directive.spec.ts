import { ApphighlightDirective } from './apphighlight.directive';

describe('ApphighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new ApphighlightDirective();
    expect(directive).toBeTruthy();
  });
});
