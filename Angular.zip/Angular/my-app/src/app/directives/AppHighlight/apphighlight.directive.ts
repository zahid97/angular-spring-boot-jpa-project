import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appApphighlight]'
})
export class ApphighlightDirective {
private bgcolor:string ;


  constructor(private el:ElementRef) { 
 //el.nativeElement.style.backgroundColor = this.bgcolor
  }

@HostListener('mouseover') onMouseOver(){
  this.bgcolor = "yellow"
}
@HostListener('mouseout') onMouseOut(){
  this.bgcolor = "white"
}

}
