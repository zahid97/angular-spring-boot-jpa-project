
public class Assignment1 {
		public static void main(String[] args){
			System.out.println("+----------------------------------+");
			System.out.println("|                               ###|");
			System.out.println("|                               ###|");
			System.out.println("|                               ###|");
			System.out.println("|                                  |");
			System.out.println("|                                  |");
			System.out.println("|                   Zahid Khan     |");
			System.out.println("|                   Mumbai         |");
			System.out.println("|                   Kurla          |");
			System.out.println("|                                  |");
			System.out.println("+----------------------------------+");
		}
		
}
